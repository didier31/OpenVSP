#include<iostream>

#define ERRMSG std::cerr << __FILE__ << ":" << __LINE__ << ":"\
    << __FUNCTION__ << "(): "
